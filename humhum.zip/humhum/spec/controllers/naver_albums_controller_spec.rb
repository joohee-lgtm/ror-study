require 'spec_helper'
require 'open-uri'
require 'nokogiri'


#require 'naver_albums_controller'

describe 'naveralbum' do
  before :each do
    @albums = Array.new
    url = "http://music.naver.com/todayMusic/index.nhn?startDate=20140210"
    source = Nokogiri::HTML(open(url))
    targetList = source.css('.tm_section')

    #puts targetList[1].css('.tm_tit').text

    for i in 1..5
      @albums << targetList[i]
    end
  end

  it '5개의 앨범을 가져온다' do
    @albums.size.should == 5

    #naver_albums_controller = NaverAlbumsController.new
    #naver_albums_controller.crawl
    #puts naver_albums_controller.parsed_albums
  end

  it '첫번째 앨범의 제목을 가져온다.' do
    target = @albums[0]
    album_title = target.css('.name').css('._title')[0]['title']
    album_title.should == 'The Film Cinema Paradiso - Love Theme'
  end

  it '첫번째 앨범의 가수이름을 가져온다.' do
    target = @albums[0]
    singer = target.css('._artist')[0]['title']
    puts singer
    singer.should == 'Ennio Morricone'
  end
end