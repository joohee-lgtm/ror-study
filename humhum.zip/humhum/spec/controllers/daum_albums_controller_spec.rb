require 'rspec'
#require 'daum_albums_controller'

describe 'daumalbum' do
  it 'should do something' do

    #daum_albums_controller = DaumAlbumsController.new
    #daum_albums_controller.crawl
    #puts daum_albums_controller.parsed_albums
  end
end