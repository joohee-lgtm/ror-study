class NaverAlbum < ActiveRecord::Base
end
