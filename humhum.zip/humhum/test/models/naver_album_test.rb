require 'test_helper'

class NaverAlbumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
