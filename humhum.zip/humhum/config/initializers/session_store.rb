# Be sure to restart your server when you modify this file.

Humhum::Application.config.session_store :cookie_store, key: '_humhum_session'
