require 'test_helper'

class NaverAlbumsControllerTest < ActionController::TestCase
  setup do
    @naver_album = naver_albums(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:naver_albums)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create naver_album" do
    assert_difference('NaverAlbum.count') do
      post :create, naver_album: {  }
    end

    assert_redirected_to naver_album_path(assigns(:naver_album))
  end

  test "should show naver_album" do
    get :show, id: @naver_album
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @naver_album
    assert_response :success
  end

  test "should update naver_album" do
    patch :update, id: @naver_album, naver_album: {  }
    assert_redirected_to naver_album_path(assigns(:naver_album))
  end

  test "should destroy naver_album" do
    assert_difference('NaverAlbum.count', -1) do
      delete :destroy, id: @naver_album
    end

    assert_redirected_to naver_albums_path
  end
end
