require 'spec_helper'
require 'open-uri'
require 'nokogiri'

describe DaumAlbum do

  it '다음 음악 추천 앨범 가져오기(?)' do

      url = "http://music.daum.net/imagene/detail?award_id=381"
      source = Nokogiri::HTML(open(url))

      #puts source
      albums = source.css('.wrap_album')
      albums[0].css('.tit_album a')[0]['title'].should == "Psychemoon"

      #albums.each do |album|
      #  title = album.css('.tit_album a')[0]['title'] //a가 여러개
      #  image_name = album.css('.box_album a img')[0]['src']
      #  review_writer = album.css('.cont_review .tit').text
      #  review = album.css('.cont_review .desc p').text
      #
      #  parsed_album = {title: title,
      #                  image_name: image_name,
      #                  review_writer: review_writer,
      #                  review: review};
      #end
  end
end