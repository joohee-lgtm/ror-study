#encoding : utf-8
require 'spec_helper'

describe "태그 가져오기" do
  before :each do
    @div = 'div'
    @html = "<#{@div}>content</#{@div}>"
    @tag = TagParser.new(@html)
  end

  it "성공!" do
    @tag.tag.should == @div
  end
end