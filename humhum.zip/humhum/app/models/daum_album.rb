class DaumAlbum < ActiveRecord::Base
end
