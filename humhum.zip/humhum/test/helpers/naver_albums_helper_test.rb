require 'test_helper'

class NaverAlbumsHelperTest < ActionView::TestCase
end
