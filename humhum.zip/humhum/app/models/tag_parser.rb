class TagParser
  attr_reader :tag
  def initialize(html)
    header  = html.split('>')[0].scan(/\w+/)
    @tag = header[0]
  end
end