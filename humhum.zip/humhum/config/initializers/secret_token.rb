# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Humhum::Application.config.secret_key_base = '1bf9fd07d14167ea2e08d644e9f290b233da4b02f0e9875ae61c292b16d05f3c96b88667ff762c0e6d6a62012c0b030466f58c96ffae07f84f4a2e4b880d26e8'
