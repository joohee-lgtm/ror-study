module DaumAlbumsHelper
end
