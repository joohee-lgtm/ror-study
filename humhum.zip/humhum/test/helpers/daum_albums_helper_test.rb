require 'test_helper'

class DaumAlbumsHelperTest < ActionView::TestCase
end
